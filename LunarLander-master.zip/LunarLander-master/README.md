### LunarLander

Please mind the dependencies, as mentioned in the three files:
-  LearningAlgo.py (the algorithm implementation)
-  AgentBody.py 
  -  Basic structure of the agent
  -  What it eats and splits out
-  AgentBrain.py
  -  Learning mechanism

How to run:
python LearningAlgo.py

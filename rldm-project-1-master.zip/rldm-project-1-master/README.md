# rldm-project-1

Main Files to run are:
1. Experiment1.py
2. Experiment2.py

python Experiment1  
will generate (or use if already created) 100 training sets, where each training set contains 10 sequences. Then it will run required steps to generate results corresponding to experiment 1 as explained in Richard Sutton's 1988 paper.
2 figures, one for average error and another for standard error are generated (Please see report.pdf on t-square Fig 2 and 3)

python Experiment2  
will generate (or use if already created) 100 training sets, where each training set contains 10 sequences. Then it will run required steps to generate results corresponding to experiment 2 as explained in Richard Sutton's 1988 paper.
3 figures are generated. Please see Fig 4,5 and 6 in report.pdf on t-square.

